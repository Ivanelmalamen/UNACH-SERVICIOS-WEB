<?php
$cliente = new SoapClient(null, array(
'location' => "http://localhost/WebService/servidor.php",
'uri' => "http://localhost/WebService/servidor.php",
'trace' => 1
));
try{
	$mar=$_POST['marca'];
	$mode=$_POST['modelo'];
	$pais=$_POST['pais'];
	echo $resultado=$cliente->_soapCall("InsertarDato",[$mar,$mode,$pais]);
	//echo $resultado=$cliente->_soapCall("ModificarDato",["ZTE","ZTE Blade A5 2020","China"]);
	//echo $resultado=$cliente->_soapCall("EliminarDato",["2"]);
}catch(SOAPFault $th){
	echo 'Error';
	echo $th->getMessage();
}
?>