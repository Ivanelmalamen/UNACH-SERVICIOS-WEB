<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=for, initial-scale=1.0">
	<title>Calculadora</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body>
	<div class="agrupar">
		<header class="cabecera">
			<h1>Registrar Celular</h1>
		</header>
		
	    <form action="cliente.php" method="post" class="formulario">
	       Marca :
	       <input type="text" name="marca"></br></br>
	       Modelo:
	       <input type="text" name="modelo"></br></br>
	       Pais :
	       <input type="text" name="pais"></br></br>

	       <input type="submit" value="Guardar">		
	    </form>
	</div>
	
</body>
</html>