create database celulares;
use celulares;
create table celular(clave_cel int(30) primary key AUTO_INCREMENT,  marca varchar(100), modelo varchar(100), pais int(50));
