<?php
class Conexion extends PDO{
	private $hostbd='localhost';
	private $nombrebd='celulares';
	private $usuariobd='root';
	private $passwordbd='';
	public function __construct(){
		try{
			parent::__construct('mysql:host='.$this->hostbd.';dbname='. $this->nombrebd.';
				charset=utf8', &this->usuariobd, &this->passwordbd, array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
		}catch(Exception $th){
			echo 'Error'.$th->getMessage();
			exit;
		}
	}
}
?>