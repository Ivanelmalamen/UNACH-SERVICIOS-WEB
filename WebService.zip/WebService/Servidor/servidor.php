<?php
class Celular{
	public function Descripcion($marca){
		return "Telefono".$marca;
	}
	public function InsertarDato($marca,$modelo,$pais){
		include 'conexion.php';
		$conexion= new Conexion();
		
		$consulta=$conexion->prepare("INSERT INTO celular(marca,modelo,pais) VALUES (:marca,:modelo,:pais)");
		$consulta->bindParam(":marca",$marca,PDO::PARAM_STR);
		$consulta->bindParam(":modelo",$modelo,PDO::PARAM_STR);
		$consulta->bindParam(":pais",$pais,PDO::PARAM_STR);
		$consulta->execute();
		return 1;
	}

	public function ModificarDato($id,$marca,$modelo,$pais){
		include 'conexion.php';
		$conexion = new Conexion();
		$consulta=$conexion->prepare("UPDATE celular SET nombre=:nombre, modelo=:modelo,pais=:pais WHERE id=:id");
		$consulta->bindParam(":id",$id,PDO::PARAM_STR);
		$consulta->bindParam(":marca",$marca,PDO::PARAM_STR);
		$consulta->bindParam(":modelo",$modelo,PDO::PARAM_STR);
		$consulta->bindParam(":pais",$pais,PDO::PARAM_STR);
		$consulta->execute();
		return 1;
	}

	public function EliminarDato($id){
		include 'conexion.php';
		$conexion = new Conexion();
		$consulta=$conexion->prepare("DELETE FROM celular WHERE id=:id");
		$consulta->bindParam(":id",$id,PDO::PARAM_STR);
		$consulta->execute();
		return 1;
	}
}

try {
	$server = new SoapServer(
		null,
		[
			'uri'=>'http://localhost/WebService/Servidor/servidor.php',
		]
	);
	$server->SetClass('Celular');
	$server->handle();
}catch(SOAPFault $th){
	print $th->faultstring;
}
?>